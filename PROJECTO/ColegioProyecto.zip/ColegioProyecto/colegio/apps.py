from django.apps import AppConfig


class RepresentantesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'representantes'
